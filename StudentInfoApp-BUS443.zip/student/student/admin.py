from django.contrib import admin
from student.models import Studentdetails
from course.models import Coursedetails
from enroll.models import Enrolldetails
# Register your models here.


admin.site.register(Studentdetails)
admin.site.register(Coursedetails)
admin.site.register(Enrolldetails)
