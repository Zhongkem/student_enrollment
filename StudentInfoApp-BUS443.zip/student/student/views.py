from django.shortcuts import render
from django.http import HttpResponse
from student.models import Studentdetails
from course.models import Coursedetails
from enroll.models import Enrolldetails
#import raw sql 
from django.db import connection
#pagenation 
from django.core.paginator import Paginator
#to make sure people are log in 
from django.contrib.auth.decorators import login_required
#calculate average
from django.db.models import Avg
from django.contrib import messages



# Create your views here.
@login_required
def home(request): 
    studentdata = Studentdetails.objects.all()
    numFreshmen = Studentdetails.objects.filter(year = 'Freshmen')
    numSophomore = Studentdetails.objects.filter(year = 'Sophomore')
    numJunior = Studentdetails.objects.filter(year = 'Junior')
    numSenior = Studentdetails.objects.filter(year = 'Senior')
    avgGPA = Studentdetails.objects.all().aggregate(Avg('gpa'))

    coursedata = Coursedetails.objects.all()
    Economics = Coursedetails.objects.filter(department = 'Economics')
    easternLang =Coursedetails.objects.filter(department = 'Near Eastern Languages & Civ')
    chem =Coursedetails.objects.filter(department = 'Chemistry & Chemical Biology')
    it= Coursedetails.objects.filter(department = 'I.T.')
    southasia = Coursedetails.objects.filter(department = 'South Asian Studies')
    Psychology = Coursedetails.objects.filter(department = 'Psychology')
    Medical = Coursedetails.objects.filter(department = 'Medical Sciences')
    AppliedMath =Coursedetails.objects.filter(department = 'Applied Mathematics')
    Engineering =Coursedetails.objects.filter(department = 'Engineering Sciences')
    return render(request, 'student/home.html',{'studentdata': studentdata , 'coursedata': coursedata, 'numFreshmen': numFreshmen.count, 
                                                'numSophomore': numSophomore.count,  'numJunior': numJunior.count , 'numSenior': numSenior.count,
                                                'avgGPA': avgGPA , 'ec': Economics.count ,'el': easternLang.count ,'chem': chem.count ,'it': it.count ,
                                                'sa': southasia.count ,'Psychology': Psychology.count ,'med': Medical.count ,'math': AppliedMath.count , 
                                                'engineering' :Engineering.count })

def about(request): 
    return HttpResponse('<h1>about</h1>')


def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

@login_required
def studentinfo(request):
    studentdata = Studentdetails.objects.all()
    paginator = Paginator(studentdata, 10)
    page = request.GET.get('page')
    studentminiset = paginator.get_page(page)
    return render (request, 'student/details.html', {'data': studentminiset})


@login_required
def enrollment(request):
    studentdata = Studentdetails.objects.all()
    coursedata = Coursedetails.objects.all()
    enrolldata = ''
    if('studentname' in request.session):
        fullname = request.session['studentname'].split()
        Sid=Studentdetails.objects.filter(firstname=fullname[0], lastname=fullname[1]).values_list('studentid',flat=True)[0]
        # Setting the currently selected student id as session variable so it can be accessed in any view 
        request.session['studentid'] = Sid
        enrolldata = Enrolldetails.objects.filter(studentid = Sid)
    
    if('sname' in request.GET and 'cname' not in request.GET):
        sname= request.GET.get('sname')
        request.session['studentname'] = sname
        fullname = sname.split()
        Sid=Studentdetails.objects.filter(firstname=fullname[0], lastname=fullname[1]).values_list('studentid',flat=True)[0]
        student = Enrolldetails.objects.filter(studentid = Sid)
        return render (request, 'student/enrollment.html', {'Sdata': studentdata, 'Cdata': coursedata,'Edata': student})

    if('sname' and 'cname' in request.GET):
        sname= request.GET.get('sname')
        cname= request.GET.get('cname')
        enrolldata = Enrolldetails.objects.all()
        if(cname == "Select Course"):
            messages.warning(request,"Select a course")
            return HttpResponse('Select a course')

        c = Coursedetails.objects.filter(title = cname)
        if(sname == "Select Student"):
            messages.warning(request,"Select a student")
            return HttpResponse('Select a student')
        Sid = int(request.session['studentid'])
        studentC = Enrolldetails.objects.filter(studentid = Sid)
        studentD = Studentdetails.objects.filter(studentid = Sid)
        courseTaken = studentC.filter(title = cname)
        if len(studentC) == 0:
            add_data= Enrolldetails(studentid = studentD[0].studentid,firstname = studentD[0].firstname, 
                                    lastname =studentD[0].lastname, courseid= c[0].courseid, title= c[0].title,
                                    coursename = c[0].coursename,section = c[0].section,department = c[0].department,
                                    instructorname =c[0].instructorname)
            add_data.save()
            messages.success(request, "Enroll Sucess")
            return HttpResponse("Enroll Sucess")
        elif len(studentC) >= 3:
            messages.warning(request,"Student can not be enroll in more than 3 course")
            return HttpResponse('Student can not be enroll in more than 3 course')       
        elif len(courseTaken) == 0:               
            add_data= Enrolldetails(studentid = studentD[0].studentid,firstname = studentD[0].firstname, 
                                    lastname =studentD[0].lastname, courseid= c[0].courseid, title= c[0].title,
                                    coursename = c[0].coursename,section = c[0].section,department = c[0].department,
                                    instructorname =c[0].instructorname)     
            add_data.save()
            messages.success(request, "Enroll Sucess")
            return HttpResponse("Enroll Sucess")
        elif len(courseTaken) != 0:
            messages.warning(request,"Student can not be enroll in the same course")
            return HttpResponse('Student can not be enroll in the same course')

    return render (request, 'student/enrollment.html', {'Sdata': studentdata, 'Cdata': coursedata, 'Edata': enrolldata})
   
@login_required
def courseinfo(request):
    coursedata = Coursedetails.objects.all()
    paginator = Paginator(coursedata, 10)
    page = request.GET.get('page')
    courseminiset = paginator.get_page(page)
    return render (request, 'student/coursedetails.html', {'data': courseminiset})

