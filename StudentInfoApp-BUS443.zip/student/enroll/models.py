from django.db import models

# Create your models here.
class Enrolldetails(models.Model):
    studentid = models.IntegerField()
    firstname = models.CharField(max_length =500)
    lastname = models.CharField(max_length = 500)
    courseid = models.IntegerField()
    title = models.CharField(max_length = 500)
    coursename = models.CharField(max_length = 500)
    section = models.IntegerField()
    department = models.CharField(max_length = 500)
    instructorname = models.CharField(max_length = 500)