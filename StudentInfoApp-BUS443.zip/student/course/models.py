from django.db import models

# Create your models here.
class Coursedetails(models.Model):
    courseid = models.IntegerField()
    title = models.CharField(max_length = 500)
    coursename = models.CharField(max_length = 500)
    section = models.IntegerField()
    department = models.CharField(max_length = 500)
    instructorname = models.CharField(max_length = 500)